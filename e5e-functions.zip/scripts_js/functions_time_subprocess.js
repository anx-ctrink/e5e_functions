const t = require('./functions_time.js')

t.sub_func_sleep_10()
