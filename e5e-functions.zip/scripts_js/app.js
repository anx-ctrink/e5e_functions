const t = require('./functions_time.js')

t.func_sleep_thread()